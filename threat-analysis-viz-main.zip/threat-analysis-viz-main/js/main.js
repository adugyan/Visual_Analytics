//build contents of of document viewer dynamically with <span> and D3. Append elements into the document.

//Get highlighting and font change active. 
/*a Document View displaying the original text docu-ment with highlighted entities, showing how often a
document already has been viewed, and supportingentity modification; */

function build_doc_contents(doc_elem, selected_entities)
{

}

var selected_entities = [];

// Run page building code
$().ready(function () {
	
	const header = document.querySelector('header');
	const section = document.querySelector('section');
      
    //Store json in a variable and open
  	let requestURL = 'label_config.json'
  	let request = new XMLHttpRequest();
  	request.open('GET', requestURL);
  
  	//convert and send a request
  	request.responseType = 'json';
	request.send();
  
  	//Store request response into variable 
  	request.onload = function() 
  	{
  		const content= request.response;
  		populateHeader(content);
  		showContent(content);
	}
      
  	//function to populate the header with the ID 
  	function populateHeader(obj) {
  	const myH1 = document.createElement('h1');
  	myH1.textContent = obj['id'];
  	header.appendChild(myH1);

	}
      
    //displays the rest of the information
  	function showDocument(obj) {
  	const elements = obj['members'];//stores members property into an array

  /*loop through each object in the array.
  Fill the 3 paragraphs with the "text", "prefixKey", and "suffixKey". */
  	for (let i = 0; i < elements.length; i++) 
	{
		const myArticle = document.createElement('document');
		const myH2 = document.createElement('h2');
		const myPara1 = document.createElement('p');
		const myPara2 = document.createElement('p');
		const myPara3 = document.createElement('p');


		myH2.textContent = ID[i].id;
		myPara1.textContent = 'Text: ' + elements[i].text;
		myPara2.textContent = 'PreFix Key: ' + elements[i].prefixKey;
		myPara3.textContent = 'Suffix Key:' + elements[i].suffixKey;

		//Not sure how to go about loading color
		
    }

    myArticle.appendChild(myH2);
    myArticle.appendChild(myPara1);
    myArticle.appendChild(myPara2);
    myArticle.appendChild(myPara3);
    

    section.appendChild(document);
  
}
	build_doc_contents($('#doc-window'), selected_entities, entity_weights);
});

<div id='doc-window'></div>

// Get tagged document corpus
corpus = (function() {
	var json = null;
	$.ajax({
	   'async': false,
	   'global': false,
	   'url': 'data/tagged_corpus.json',
	   'dataType': 'json',
	   'success': function(data) {
		  json = data;
	   }
	});
	return json;
})();